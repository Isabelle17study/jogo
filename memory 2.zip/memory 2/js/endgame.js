// Exibir o nome do jogador e o tempo
//const playerName = localStorage.getItem('player');
//const finalTime = localStorage.getItem('finalTime');

//document.getElementById('player-name').textContent = playerName;
//document.getElementById('final-time').textContent = finalTime;

// Recupera os dados armazenados no localStorage (nome do jogador e tempo)
const playerName = localStorage.getItem('player');
const finalTimeInSeconds = localStorage.getItem('finalTime');

// Calcula o tempo em minutos e segundos
const minutes = Math.floor(finalTimeInSeconds / 60);
const seconds = finalTimeInSeconds % 60;

// Insere os dados na página
document.getElementById('player-name').textContent = playerName;
document.getElementById('final-minutes').textContent = minutes;
document.getElementById('final-seconds').textContent = second